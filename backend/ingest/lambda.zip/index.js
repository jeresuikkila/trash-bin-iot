const { Client, Pool } = require('pg')

exports.timenow = async function(event, context, callback) {

    const pool = new Pool({
        user: 'trashbiniot',
        host: 'trash-bin-iot-test.celdux0k7g1r.eu-central-1.rds.amazonaws.com',
        database: 'trashbiniot',
        password: 'futurice',
        port: 5432,
      })

    await pool.connect()

    pool.query('SELECT NOW()', (err, res) => {
        console.log(err, res)
        res.rows.forEach((r) => console.log(r))
        pool.end()
      })
}

exports.timenow();